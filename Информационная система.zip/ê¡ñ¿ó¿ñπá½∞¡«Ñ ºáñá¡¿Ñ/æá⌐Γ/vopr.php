<link rel="shortcut icon" href="photo/3123.png" type="image/png">
 <input type="checkbox" id="hmt" class="hidden-menu-ticker">
<label class="btn-menu" for="hmt">
  <span class="first"></span>
  <span class="second"></span>
  <span class="third"></span>
</label>
<ul class="hidden-menu">
<h2>Меню</h2>
  <li><a href="index.php">Главная</a></li>  
  <li><a href="nas.php">О нас</a></li>
  <li><a href="form.php">Запись на приём</a></li>
  <li><a href="ruk.php">Руководство</a></li>  
  <li><a href="graf.php">График</a></li>
  <li><a href="vopr.php">Комментарии</a></li> 
<br>
<h2>Ресурсы</h2>
  <li><a href="https://vk.com/skyrim_mirack">Разработчик в ВК</a></li>  
  <li><a href="https://www.gosuslugi.ru/">ГосУслуги</a></li>
<br>
<img width="80px" src="photo/3123.png" align="legt">
</ul>
    
  <!-- Menu -->


  <section class="et-hero-tabs">
<?php
    //Подключение шапки
    require_once("header.php");
?>

    <h1>Социальная Защита</h1>
    <h3>Управление социальной защиты (соцзащиты) населения по Канскому району 
<br>
и г. Канску в г.Канск на ул. 40 Лет Октября
<br>
<img width="80px" src="photo/3123.png" align="center">
<br>


</h3>
    <div class="et-hero-tabs-container">
      <a class="et-hero-tab" href="#1">Оставить комментарий</a>
      <a class="et-hero-tab" href="#2">Комментарии от пользователей</a>
      <a class="et-hero-tab" href="#8">Авторские права</a>
      <span class="et-hero-tab-slider" style="width: 0px; left: 0px;"></span>
<div class="toper">
<a href="#header" class="arrow-down2">
    <span></span>
    <span></span>
    <span></span>
</a>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<a href="#8" class="arrow-down">
    <span></span>
    <span></span>
    <span></span>
</a>
</div>
    <script src="https://apps.elfsight.com/p/platform.js" defer></script>
<div class="elfsight-app-0be2180c-b1b1-443e-ba64-244b90ce4ffa"></div>
    </div>
  </section>




  <!-- Info -->
  <main class="et-main">

    <section class="et-slide" id="1">
      <h1>Оставить комментарий</h1>
      <h3>
          
         Вам необходимо авторизироваться!

</h3>

<?php
  /* Принимаем данные из формы */
  $name = $_POST["name"];
  $page_id = $_POST["page_id"];
  $text_comment = $_POST["text_comment"];
  $name = htmlspecialchars($name);// Преобразуем спецсимволы в HTML-сущности
  $text_comment = htmlspecialchars($text_comment);// Преобразуем спецсимволы в HTML-сущности
  $mysqli = new mysqli("", "", "", "");// Подключается к базе данных
  $mysqli->query("INSERT INTO `comments` (`name`, `page_id`, `text_comment`) VALUES ('$name', '$page_id', '$text_comment')");// Добавляем комментарий в таблицу
  header("Location: ".$_SERVER["HTTP_REFERER"]);// Делаем реридект обратно
?>
<h3>
    

</h3>
     </section>
     
     <div class= et-slide4 id="2">
         <center><h1> Комментарии от пользователей </h1> </center>
     </div>
         <br>
         <br>
     <?php
  $page_id = 150;// Уникальный идентификатор страницы (статьи или поста)
  $mysqli = new mysqli("127.0.0.1", "u107907_u103620", "Mirack123", "u107907_comment");// Подключается к базе данных
  $result_set = $mysqli->query("SELECT * FROM `comments` WHERE `page_id`='$page_id'"); //Вытаскиваем все комментарии для данной страницы
  while ($row = $result_set->fetch_assoc()) {
echo "<img width='50px' src='photo/75568585.png'> Пользователь - {$row['name']}: {$row['text_comment']}";
  echo "<br />";
  }
?>
 
<?php
    //Подключение подвала
    require_once("footer.php");
?>