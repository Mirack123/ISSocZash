        <div id="footer">

    <section class="et-slide2" id="8">

      <h1>Авторские права</h1>
      <h3>Сайт разработан студентом Канского технологического колледжа: Ле Никитой Вуевичем.
<br>
ВК разработчика: <a href="https://vk.com/skyrim_mirack">
https://vk.com/skyrim_mirack</a>
<br>
ГосУслуги: <a href="https://www.gosuslugi.ru/">
https://www.gosuslugi.ru/</a>
<br>
Сайт создан для ТО КГКУ "УСЗН" по г Канску и Канскому району.
<br>
663604, Красноярский край, г.Канск,
ул. 40 лет Октября, д. 60/1.
<br>
Телефон: 3-60-43
<br>
E-mail: szn24@szn24.ru
<br>
<img width="80px" src="photo/3123.png" align="center">
<br>
<a onclick="setStyleSheet('css/style57349.css')" href="#">Режим дальтоника</a>
<a onclick="setStyleSheet('css/styles16.css')" href="#">Обычный режим</a>
        
</h3>
    </section>


  </main>
 
   <script src="https://cpwebassets.codepen.io/assets/common/stopExecutionOnTimeout-157cd5b220a5c80d4ff8e0e70ac069bffd87a61252088146915e8726e5d9f147.js"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
      <script id="rendered-js">
class StickyNavigation {

  constructor() {
    this.currentId = null;
    this.currentTab = null;
    this.tabContainerHeight = 70;
    let self = this;
    $('.et-hero-tab').click(function () {
      self.onTabClick(event, $(this));
    });
    $(window).scroll(() => {this.onScroll();});
    $(window).resize(() => {this.onResize();});
  }

  onTabClick(event, element) {
    event.preventDefault();
    let scrollTop = $(element.attr('href')).offset().top - this.tabContainerHeight + 1;
    $('html, body').animate({ scrollTop: scrollTop }, 600);
  }

  onScroll() {
    this.checkTabContainerPosition();
    this.findCurrentTabSelector();
  }

  onResize() {
    if (this.currentId) {
      this.setSliderCss();
    }
  }

  checkTabContainerPosition() {
    let offset = $('.et-hero-tabs').offset().top + $('.et-hero-tabs').height() - this.tabContainerHeight;
    if ($(window).scrollTop() > offset) {
      $('.et-hero-tabs-container').addClass('et-hero-tabs-container--top');
    } else
    {
      $('.et-hero-tabs-container').removeClass('et-hero-tabs-container--top');
    }
  }

  findCurrentTabSelector(element) {
    let newCurrentId;
    let newCurrentTab;
    let self = this;
    $('.et-hero-tab').each(function () {
      let id = $(this).attr('href');
      let offsetTop = $(id).offset().top - self.tabContainerHeight;
      let offsetBottom = $(id).offset().top + $(id).height() - self.tabContainerHeight;
      if ($(window).scrollTop() > offsetTop && $(window).scrollTop() < offsetBottom) {
        newCurrentId = id;
        newCurrentTab = $(this);
      }
    });
    if (this.currentId != newCurrentId || this.currentId === null) {
      this.currentId = newCurrentId;
      this.currentTab = newCurrentTab;
      this.setSliderCss();
    }
  }

  setSliderCss() {
    let width = 0;
    let left = 0;
    if (this.currentTab) {
      width = this.currentTab.css('width');
      left = this.currentTab.offset().left;
    }
    $('.et-hero-tab-slider').css('width', width);
    $('.et-hero-tab-slider').css('left', left);
  }}



new StickyNavigation();
//# sourceURL=pen.js
    </script>
    
        </div>
        <div id="preloader_malc">
            	<div>
		Подождите, идет загрузка сайта ...

	</div>
</div>

<style type="text/css">

	#preloader_malc {

		position: fixed;
                top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		background-image: url("load.gif");
		z-index: 99;
  -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
  background-position: center center;
  background-attachment: fixed;
  background-repeat: no-repeat;
	}

	#preloader_malc div {
		 background: #FFF;
		width: 260px;
		height: 40px;
		line-height: 40px;
		border-radius: 8px;
		font-family: arial;
		font-size: 15px;
		color: #111;
		text-align: center;
		box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4);
		position: fixed;
		z-index: 999;
		top: 20%;
		left: 0;
		right: 0;
		bottom: 0;
		margin: auto
	}
</style>

<script type="text/javascript">

	window.onload = function() {

		setTimeout(function() {

document.getElementById("preloader_malc").style.display = "none";
                        

		}, 400);

	};

</script>

    </body>
</html>