
 
<link rel="shortcut icon" href="photo/3123.png" type="image/png">
 <input type="checkbox" id="hmt" class="hidden-menu-ticker">
<label class="btn-menu" for="hmt">
  <span class="first"></span>
  <span class="second"></span>
  <span class="third"></span>
</label>
<ul class="hidden-menu">
<h2>Меню</h2>
  <li><a href="index1.php">Главная</a></li>  
  <li><a href="nas1.php">О нас</a></li>
  <li><a href="form1.php">Запись на приём</a></li>
  <li><a href="ruk1.php">Руководство</a></li>  
  <li><a href="graf1.php">График</a></li>
  <li><a href="vopr1.php">Комментарии</a></li> 
<br>
<h2>Ресурсы</h2>
  <li><a href="https://vk.com/skyrim_mirack">Разработчик в ВК</a></li>  
  <li><a href="https://www.gosuslugi.ru/">ГосУслуги</a></li>
<br>
<img width="80px" src="photo/3123.png" align="legt">
</ul>
    
  <!-- Menu -->


  <section class="et-hero-tabs">
<?php
    //Подключение шапки
    require_once("header.php");
    
 if(!isset($_SESSION["email"]) && !isset($_SESSION["password"])){
         
         echo "Вы должны авторизироваться чтобы просмотреть данную страницу!
         <br>
         или перейдите на не авторизированную часть: <a href='index.php'>ПЕРЕЙТИ</a>
         ";
exit();    //Закрываем доступ не авторизированным пользователям

                }else{


                
                }
    
?>

    <h1>Социальная Защита</h1>
    <h3>Управление социальной защиты (соцзащиты) населения по Канскому району 
<br>
и г. Канску в г.Канск на ул. 40 Лет Октября
<br>
<img width="80px" src="photo/3123.png" align="center">
<br>


</h3>
    <div class="et-hero-tabs-container">
      <a class="et-hero-tab" href="#1">О нас</a>
      <a class="et-hero-tab" href="#2">Руководство</a>
      <a class="et-hero-tab" href="#3">График работы</a>
      <a class="et-hero-tab" href="#4">Запись на приём</a>
      <a class="et-hero-tab" href="#5">Комментарии</a>
      <a class="et-hero-tab" href="#8">Авторские права</a>
      <span class="et-hero-tab-slider" style="width: 0px; left: 0px;"></span>
<div class="toper">
<a href="#header" class="arrow-down2">
    <span></span>
    <span></span>
    <span></span>
</a>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<a href="#8" class="arrow-down">
    <span></span>
    <span></span>
    <span></span>
</a>
</div>
    <script src="https://apps.elfsight.com/p/platform.js" defer></script>
<div class="elfsight-app-0be2180c-b1b1-443e-ba64-244b90ce4ffa"></div>
    </div>
  </section>




  <!-- Info -->
  <main class="et-main">

    <section class="et-slide" id="1">
      <h1>О нас</h1>
      <h3>Кто мы такие? Что мы из себя представляем? 
Каковы наши цели и какова наша история? Что является нашей гордостью? 
<br>
Ответы на эти и многие другие вопросы вы сможете узнать в этом разделе!
<br>
<br>
<a href="nas1.php" class="btn btn3">УЗНАТЬ О НАС!</a>

<center><div class="slide">

    <input type="radio" name="slider1" id="slider2_1" checked="checked">
    <label for="slider2_1"></label>
    <div><p> О нас №1.</p> <img width="500px" height="300px" src="photo/22.11.16-1.jpg"></div>
    <label for="slider2_2"></label>

    <input type="radio" name="slider2" id="slider2_2">
    <label for="slider2_2"></label>
    <div><p>О нас №2.</p> <img width="500px" height="300px" src="photo/XXL.jpg"></div>
    <label for="slider2_3"></label>

    <input type="radio" name="slider3" id="slider2_3">
    <label for="slider2_3"></label>
    <div><p>О нас №3.</p> <img width="500px" height="300px" src="photo/5c65479d06f2218601fc479807f60515.jpg"></div>
    <label for="slider2_1"></label>

</div></center>

</h3>
    </section>
    
        <section class="et-slide" id="2">
      <h1>Руководство</h1>
      <h3>Каковы возможности сайта и прикладной программы?
      Каким образом разрабатывался сайт и прикладная программа?
<br>
Узнать ответы вы сможете тут!
<br>
<br>
<a href="ruk1.php" class="btn btn3">РУКОВОДСТВО!</a>

<center><div class="slide">

    <input type="radio" name="slider4" id="slider2_4" checked="checked">
    <label for="slider2_4"></label>
    <div><p>Руководство №1.</p> <img width="500px" height="300px" src="photo/231321.PNG"></div>
    <label for="slider2_5"></label>

    <input type="radio" name="slider5" id="slider2_5">
    <label for="slider2_5"></label>
    <div><p>Руководство №2.</p> <img width="500px" height="300px" src="photo/75767.PNG"></div>
    <label for="slider2_6"></label>

    <input type="radio" name="slider6" id="slider2_6">
    <label for="slider2_6"></label>
    <div><p>Руководство №3.</p> <img width="500px" height="300px" src="photo/6456456.PNG"></div>
    <label for="slider2_4"></label>

</div></center>

</h3>
    </section>
    
        <section class="et-slide" id="3">
      <h1>График</h1>
      <h3>Здесь вы сможете узнать наш график работы и местоположение!
<br>
<br>
<a href="graf1.html" class="btn btn3">УЗНАТЬ ГРАФИК!</a>

</h3>
    </section>
    
        <section class="et-slide" id="4">
      <h1>Запись на приём</h1>
      <h3>В данном разделе вы сможете записаться на приём в социальную защиту!
<br>
<br>
<a href="form1.php" class="btn btn3">ЗАПИСАТЬСЯ!</a>


</h3>
    </section>

    <section class="et-slide" id="5">
      <h1>Комментарии</h1>
      <h3>Выражайте свои мысли о сайте или клане здесь, в комментариях!
<br>
<br>
<a href="vopr1.php" class="btn btn3">НАПИСАТЬ КОММЕНТАРИЙ!</a>
</h3>
    </section>
 
<?php
    //Подключение подвала
    require_once("footer.php");
?>