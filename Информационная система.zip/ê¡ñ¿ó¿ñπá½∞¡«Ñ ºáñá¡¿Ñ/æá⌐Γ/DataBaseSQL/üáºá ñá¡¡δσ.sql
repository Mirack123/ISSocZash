-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Май 31 2021 г., 16:28
-- Версия сервера: 5.5.68-MariaDB-cll-lve
-- Версия PHP: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `u107907_comment`
--

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(20) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `page_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `text_comment` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=cp1257 COLLATE=cp1257_bin;

--
-- Дамп данных таблицы `comments`
--

INSERT INTO `comments` (`id`, `name`, `page_id`, `text_comment`) VALUES
(13, '******', '150', 'Супер сайт!'),
(18, '******', '150', 'Крутой сайт, Афанасьев одобряет!)'),

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_status` tinyint(1) NOT NULL DEFAULT '0',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `email_status`, `password`) VALUES
(1, '******', '******', '******', 0, 'b5d5e75b4d03570852d5173fe02a10c0'),
(2, '******', '******', '******', 0, 'b5d5e75b4d03570852d5173fe02a10c0'),
(7, '******', '******', '******', 0, 'b58bc14b138c0ed8e108a5124263f517'),
(8, '******', '******', '******', 0, '9889382b40b9362d1018b2dbe771ebc7'),
(9, '******', '******', '******', 0, 'b5d5e75b4d03570852d5173fe02a10c0'),
(10, '******', '******', '******', 0, 'b5d5e75b4d03570852d5173fe02a10c0'),
(11, '******', '******', '******', 0, 'a4c4c6565a5c742de03c5d43d40fef4f');

-- --------------------------------------------------------

--
-- Структура таблицы `Zapros`
--

CREATE TABLE IF NOT EXISTS `Zapros` (
  `id` int(20) NOT NULL,
  `FIO` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `DataR` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Address` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `TypeObr` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `DObr` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `TObr` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Okno` int(5) NOT NULL,
  `tel` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=cp1257 COLLATE=cp1257_bin;

--
-- Дамп данных таблицы `Zapros`
--

INSERT INTO `Zapros` (`id`, `FIO`, `DataR`, `Address`, `TypeObr`, `DObr`, `TObr`, `Okno`, `tel`) VALUES
(4, '******', '******', '******', 'Смена персональных данных', '2002-07-05', 'с 15:40 до 16:00', 3, '******');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);


--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Индексы таблицы `Zapros`
--
ALTER TABLE `Zapros`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=70;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT для таблицы `Zapros`
--
ALTER TABLE `Zapros`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
