<link rel="shortcut icon" href="photo/3123.png" type="image/png">
 <input type="checkbox" id="hmt" class="hidden-menu-ticker">
<label class="btn-menu" for="hmt">
  <span class="first"></span>
  <span class="second"></span>
  <span class="third"></span>
</label>
<ul class="hidden-menu">
<h2>Меню</h2>
  <li><a href="index.php">Главная</a></li>  
  <li><a href="nas.php">О нас</a></li>
  <li><a href="form.php">Запись на приём</a></li>
  <li><a href="ruk.php">Руководство</a></li>  
  <li><a href="graf.php">График</a></li>
  <li><a href="vopr.php">Комментарии</a></li> 
<br>
<h2>Ресурсы</h2>
  <li><a href="https://vk.com/skyrim_mirack">Разработчик в ВК</a></li>  
  <li><a href="https://www.gosuslugi.ru/">ГосУслуги</a></li>
<br>
<img width="80px" src="photo/3123.png" align="legt">
</ul>
    
  <!-- Menu -->


  <section class="et-hero-tabs">
<?php
    //Подключение шапки
    require_once("header.php");
?>

    <h1>Социальная Защита</h1>
    <h3>Управление социальной защиты (соцзащиты) населения по Канскому району 
<br>
и г. Канску в г.Канск на ул. 40 Лет Октября
<br>
<img width="80px" src="photo/3123.png" align="center">
<br>


</h3>
    <div class="et-hero-tabs-container">
      <a class="et-hero-tab" href="#1">О нас</a>
      <a class="et-hero-tab" href="#2">О эмблеме</a>
      <a class="et-hero-tab" href="#3">О дизайне</a>
      <a class="et-hero-tab" href="#8">Авторские права</a>
      <span class="et-hero-tab-slider" style="width: 0px; left: 0px;"></span>
<div class="toper">
<a href="#header" class="arrow-down2">
    <span></span>
    <span></span>
    <span></span>
</a>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<a href="#8" class="arrow-down">
    <span></span>
    <span></span>
    <span></span>
</a>
</div>
    <script src="https://apps.elfsight.com/p/platform.js" defer></script>
<div class="elfsight-app-0be2180c-b1b1-443e-ba64-244b90ce4ffa"></div>
    </div>
  </section>




  <!-- Info -->
  <main class="et-main">

    <section class="et-slide" id="1">
      <h1>О нас</h1>
      <h3>
          
Управление социальной защиты (соцзащиты) населения по Канскому району 
и г. Канску в г.Канск на ул. 40 Лет Октября
<br>
<br>
Адрес:
<br>
Красноярский край, г. Канск, 40 лет Октября, 60/1
<br>
<br>
Телефоны:
<br>
8-800-35-01-394 — бесплатная горячая линия: льготы, пособия, субсидии 
и др. юридические вопросы.
<br>
Простите, но консультации по вопросам работы отделений соцзащиты,
а также жалобы и предложения по данному телефону не обрабатываем.
<br>
+7(39161) 3-26-70
<br>
+7(39161) 3-55-74 
<br>

</h3>

     </section>
     
         <section class="et-slide" id="2">
      <h1>О эмблеме</h1>
      <h3>
          
         Эмблема создана в стиле дизайна сайта, сердце символизирует социальное общество,
         а голубая птица свободу данного социального общества.
         <br>
                  <br>
         <img width="200px"  src="photo/3123.png">

</h3>

     </section>
     
         <section class="et-slide" id="3">
      <h1>О дизайне</h1>
      <h3>
          
         Дизайн создан в минималистическом стиле, основными цветами являются:
         <br>
         Белый - символизирует свободу и независимость, а так же мир и чистоту.
                  <br>
         Оттенки синего - симврлизирует веру и постоянство.
                  <br>
         Красный - символизирует энергию, силу и кровь, которая была пролита за Отечество.
                  <br>
                           <br>
         <img width="550px" height="300px" src="photo/231321.PNG">

</h3>

     </section>

<?php
    //Подключение подвала
    require_once("footer.php");
?>