<link rel="shortcut icon" href="photo/3123.png" type="image/png">
 <input type="checkbox" id="hmt" class="hidden-menu-ticker">
<label class="btn-menu" for="hmt">
  <span class="first"></span>
  <span class="second"></span>
  <span class="third"></span>
</label>
<ul class="hidden-menu">
<h2>Меню</h2>
  <li><a href="index1.php">Главная</a></li>  
  <li><a href="nas1.php">О нас</a></li>
  <li><a href="form1.php">Запись на приём</a></li>
  <li><a href="ruk1.php">Руководство</a></li>  
  <li><a href="graf1.php">График</a></li>
  <li><a href="vopr1.php">Комментарии</a></li> 
<br>
<h2>Ресурсы</h2>
  <li><a href="https://vk.com/skyrim_mirack">Разработчик в ВК</a></li>  
  <li><a href="https://www.gosuslugi.ru/">ГосУслуги</a></li>
<br>
<img width="80px" src="photo/3123.png" align="legt">
</ul>
    
  <!-- Menu -->


  <section class="et-hero-tabs">
<?php
    //Подключение шапки
    require_once("header.php");
    
     if(!isset($_SESSION["email"]) && !isset($_SESSION["password"])){
         
                  echo "Вы должны авторизироваться чтобы просмотреть данную страницу!
         <br>
         или перейдите на не авторизированную часть: <a href='index.php'>ПЕРЕЙТИ</a>
         ";
         
exit();  //Закрываем доступ не авторизированным пользователям

                }else{


                
                }
?>

    <h1>Социальная Защита</h1>
    <h3>Управление социальной защиты (соцзащиты) населения по Канскому району 
<br>
и г. Канску в г.Канск на ул. 40 Лет Октября
<br>
<img width="80px" src="photo/3123.png" align="center">
<br>


</h3>
    <div class="et-hero-tabs-container">
      <a class="et-hero-tab" href="#1">Записаться на приём</a>
      <a class="et-hero-tab" href="#8">Авторские права</a>
      <span class="et-hero-tab-slider" style="width: 0px; left: 0px;"></span>
<div class="toper">
<a href="#header" class="arrow-down2">
    <span></span>
    <span></span>
    <span></span>
</a>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<a href="#8" class="arrow-down">
    <span></span>
    <span></span>
    <span></span>
</a>
</div>
    <script src="https://apps.elfsight.com/p/platform.js" defer></script>
<div class="elfsight-app-0be2180c-b1b1-443e-ba64-244b90ce4ffa"></div>
    </div>
  </section>




  <!-- Info -->
  <main class="et-main">

    <section class="et-slide3" id="1">
      <h1>Записаться на приём</h1>
      <h3>
          
  <form action="form12.php" method="post">

<table>
    <tr><td>*Фамилия Имя Отчество <br><br></td><td><input type = "text" name="FIO" maxlenght=30 size=30></td></tr>
    <tr><td>*Ваша дата рождения<br><br></td><td><input type = "date" name="DataR" maxlenght=30 size=30></td></tr>
    <tr><td>*Ваш адрес<br><br></td><td><input type = "text" name="Address" maxlenght=30 size=30></td></tr>
    
    <tr><td><div class="guruweba_example_infofield">*Тема обращения<br><br></div></td>
  
 <td> <select name="TypeObr" required="required">
    <option value="">Выберите тему</option>
    <option>Смена персональных данных</option>
    <option>Смена состава семьи</option>
    <option>Изменение дохода</option>
    <option>Личное обращение</option>
  </select></td></tr>
  
    <tr><td>*На какую дату вас записать?<br><br></td><td>

        <input type = "date" name="DObr" maxlenght=30 size=30></td></tr>
    
        <tr><td><div class="guruweba_example_infofield">*На какое время	вас записать?<br><br></div></td>
  
 <td> <select name="TObr" required="required">
    <option value="">Выберите время</option>
    <option>с 9:00 до 9:20</option>
    <option> с 9:20 до 9:40</option>
    <option>с 9:40 до 10:00</option>
    <option>с 10:00 до 10:20</option>
        <option>с 10:20 до 10:40</option>
    <option>с 10:40 до 11:00</option>
    <option>с 11:00 до 11:20</option>
    <option>с 11:20 до 11:40</option>
    
        <option>с 11:40 до 12:00</option>
    <option>с 12:00 до 12:20</option>
    <option>с 12:20 до 12:40</option>
    <option>с 12:40 до 13:00</option>
        <option>с 14:00 до 14:20</option>
    <option>с 14:20 до 14:40</option>
    <option>с 14:40 до 15:00</option>
    <option>с 15:00 до 15:20</option>
    
            <option>с 15:20 до 15:40</option>
    <option>с 15:40 до 16:00</option>
    <option>с 16:00 до 16:20</option>
    <option>с 16:20 до 16:40</option>
        <option>с 16:40 до 17:00</option>
    <option>с 17:00 до 17:20</option>
    <option>с 17:20 до 17:40</option>
    <option>с 17:40 до 18:00</option>
  </select></td></tr>

    
        <tr><td><div class="guruweba_example_infofield">*В какое окно вас записать?<br><br></div></td>
  
 <td> <select name="Okno" required="required">
    <option value="">Выберите окно</option>
    <option>1</option>
    <option>2</option>
    <option>3</option>
    <option>4</option>
        <option>5</option>
    <option>6</option>
    <option>7</option>
  </select></td></tr>
  
    <tr><td>*Ваш номер телефона<br><br></td><td><input type = "tel" name="tel" maxlenght=30 size=30></td></tr>
</table>

<input type="checkbox" required > Нажимая кнопку "Отправить" Вы даёте свое согласие на обработку введенной
<br>
<br>
<br>
персональной информации в соответствии с Федеральным Законом №152-ФЗ
<br>
<br>
<br>
от 27.07.2006 "О персональных данных"

<table>
    <tr><td><br><br><input type="submit" name="go" class="btn btn3" value="Отправить"></td></tr>
    
</table>

</form>

</h3>

     </section>

<?php
    //Подключение подвала
    require_once("footer.php");
?>