<link rel="shortcut icon" href="photo/3123.png" type="image/png">
 <input type="checkbox" id="hmt" class="hidden-menu-ticker">
<label class="btn-menu" for="hmt">
  <span class="first"></span>
  <span class="second"></span>
  <span class="third"></span>
</label>
<ul class="hidden-menu">
<h2>Меню</h2>
  <li><a href="index.php">Главная</a></li>  
  <li><a href="nas.php">О нас</a></li>
  <li><a href="form.php">Запись на приём</a></li>
  <li><a href="ruk.php">Руководство</a></li>  
  <li><a href="graf.php">График</a></li>
  <li><a href="vopr.php">Комментарии</a></li> 
<br>
<h2>Ресурсы</h2>
  <li><a href="https://vk.com/skyrim_mirack">Разработчик в ВК</a></li>  
  <li><a href="https://www.gosuslugi.ru/">ГосУслуги</a></li>
<br>
<img width="80px" src="photo/3123.png" align="legt">
</ul>
    
  <!-- Menu -->


  <section class="et-hero-tabs">
<?php
    //Подключение шапки
    require_once("header.php");
    
         if(!isset($_SESSION["email"]) && !isset($_SESSION["password"])){
         
                  echo "Вы должны авторизироваться чтобы просмотреть данную страницу!
         <br>
         или перейдите на не авторизированную часть: <a href='index.php'>ПЕРЕЙТИ</a>
         ";
         
exit();  //Закрываем доступ не авторизированным пользователям

                }else{


                
                }
    
?>

    <h1>Социальная Защита</h1>
    <h3>Управление социальной защиты (соцзащиты) населения по Канскому району 
<br>
и г. Канску в г.Канск на ул. 40 Лет Октября
<br>
<img width="80px" src="photo/3123.png" align="center">
<br>


</h3>
    <div class="et-hero-tabs-container">
      <a class="et-hero-tab" href="#1">График работы</a>
      <a class="et-hero-tab" href="#2">Местоположение</a>
      <a class="et-hero-tab" href="#8">Авторские права</a>
      <span class="et-hero-tab-slider" style="width: 0px; left: 0px;"></span>
<div class="toper">
<a href="#header" class="arrow-down2">
    <span></span>
    <span></span>
    <span></span>
</a>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<a href="#8" class="arrow-down">
    <span></span>
    <span></span>
    <span></span>
</a>
</div>
    <script src="https://apps.elfsight.com/p/platform.js" defer></script>
<div class="elfsight-app-0be2180c-b1b1-443e-ba64-244b90ce4ffa"></div>
    </div>
  </section>




  <!-- Info -->
  <main class="et-main">

    <section class="et-slide" id="1">
      <h1>График работы</h1>
      <h3>
          
понедельник: 09:00-18:00, перерыв 13:00-14:00;
<br>
вторник: 09:00-18:00, перерыв 13:00-14:00;
<br>
среда: 09:00-18:00, перерыв 13:00-14:00;
<br>
четверг: 09:00-18:00, перерыв 13:00-14:00;
<br>
пятница: 09:00-18:00, перерыв 13:00-14:00;
<br>
суббота: выходной;
<br>
воскресенье: выходной.

</h3>

     </section>
     
         <section class="et-slide" id="2">
      <h1>Местоположение</h1>
      <h3>
          
Как добраться на общественном транспорте:
    <br>
    <br>
остановка Драматический театр. Расстояние: 160 м.
    <br>
    <br>
 <br>
Показать на карте: </p></a></H2>
        <br>
    <br>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2217.706231263759!2d95.70225391566579!3d56.23131158068403!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5cded26ae364b077%3A0x24505498e314effa!2z0YPQuy4gNDAg0LvQtdGCINCe0LrRgtGP0LHRgNGPLCA2MC8xLCDQmtCw0L3RgdC6LCDQmtGA0LDRgdC90L7Rj9GA0YHQutC40Lkg0LrRgNCw0LksIDY2MzYwNA!5e0!3m2!1sru!2sru!4v1608709810587!5m2!1sru!2sru" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>


</h3>

     </section>

<?php
    //Подключение подвала
    require_once("footer.php");
?>