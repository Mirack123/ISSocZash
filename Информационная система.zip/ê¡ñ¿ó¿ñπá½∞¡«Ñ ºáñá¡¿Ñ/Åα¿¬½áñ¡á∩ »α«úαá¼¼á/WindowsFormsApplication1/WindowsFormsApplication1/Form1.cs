﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frmLogon : Form
    {
        int ttime;
        
        public frmLogon()
        {
            InitializeComponent();
        }

        private void tmrTimer_Tick(object sender, EventArgs e)
        {
            lblTimer.Text = "Автоматический выход через " + ttime.ToString() + " сек.";
            ttime = ttime - 1;
            if (ttime == 0)
            {
                tmrTimer.Stop();
                MessageBox.Show("Время набора пароля истекло. Программа будет закрыта.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            tmrTimer.Stop();
            Application.Exit();//именно этот оператор, т. к. у нас еще открыта форма frmMain
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (txtPassword.Text == "0000")
            {
                tmrTimer.Stop();
                this.Close();
            }
            else
            {
                MessageBox.Show("Введен неверный пароль. Повторите попытку.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ttime = 10;//даем еще одну попытку ввода пароля. Если Вам это не нужно, вместо этой строки напишите Application.Exit()
            }
        }

        private void frmLogon_Load(object sender, EventArgs e)
        {
            ttime = 10;//обратный отсчет
        }
    }
}
