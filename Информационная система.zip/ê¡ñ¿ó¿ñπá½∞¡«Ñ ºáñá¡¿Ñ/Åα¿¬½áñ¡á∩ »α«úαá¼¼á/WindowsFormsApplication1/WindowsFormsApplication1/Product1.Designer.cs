﻿
namespace WindowsFormsApplication1
{
    partial class Product1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Product1));
            this.button3 = new System.Windows.Forms.Button();
            this.типПродукцииBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sbitDataSet = new WindowsFormsApplication1.SbitDataSet();
            this.socZash1DataSet = new WindowsFormsApplication1.SocZash1DataSet();
            this.типОбращенияBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.тип_обращенияTableAdapter = new WindowsFormsApplication1.SocZash1DataSetTableAdapters.Тип_обращенияTableAdapter();
            this.тип_продукцииTableAdapter = new WindowsFormsApplication1.SbitDataSetTableAdapters.Тип_продукцииTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.типПродукцииBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sbitDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.socZash1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типОбращенияBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.button3.Location = new System.Drawing.Point(474, 295);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(113, 60);
            this.button3.TabIndex = 5;
            this.button3.Text = "Выход";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // типПродукцииBindingSource
            // 
            this.типПродукцииBindingSource.DataMember = "Тип продукции";
            this.типПродукцииBindingSource.DataSource = this.sbitDataSet;
            // 
            // sbitDataSet
            // 
            this.sbitDataSet.DataSetName = "SbitDataSet";
            this.sbitDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // socZash1DataSet
            // 
            this.socZash1DataSet.DataSetName = "SocZash1DataSet";
            this.socZash1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // типОбращенияBindingSource
            // 
            this.типОбращенияBindingSource.DataMember = "Тип обращения";
            this.типОбращенияBindingSource.DataSource = this.socZash1DataSet;
            // 
            // тип_обращенияTableAdapter
            // 
            this.тип_обращенияTableAdapter.ClearBeforeFill = true;
            // 
            // тип_продукцииTableAdapter
            // 
            this.тип_продукцииTableAdapter.ClearBeforeFill = true;
            // 
            // Product1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 500);
            this.Controls.Add(this.button3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Product1";
            this.Text = "Продукция";
            this.Load += new System.EventHandler(this.Product1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.типПродукцииBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sbitDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.socZash1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типОбращенияBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button3;
        private SocZash1DataSet socZash1DataSet;
        private System.Windows.Forms.BindingSource типОбращенияBindingSource;
        private SocZash1DataSetTableAdapters.Тип_обращенияTableAdapter тип_обращенияTableAdapter;
        private SbitDataSet sbitDataSet;
        private System.Windows.Forms.BindingSource типПродукцииBindingSource;
        private SbitDataSetTableAdapters.Тип_продукцииTableAdapter тип_продукцииTableAdapter;
    }
}