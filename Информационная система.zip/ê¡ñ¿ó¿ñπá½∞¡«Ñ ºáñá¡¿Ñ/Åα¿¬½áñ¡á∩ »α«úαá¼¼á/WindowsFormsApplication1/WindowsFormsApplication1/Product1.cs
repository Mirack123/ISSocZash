﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Product1 : Form
    {
        public Product1()
        {
            InitializeComponent();
        }

        private void Product1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "sbitDataSet.Тип_продукции". При необходимости она может быть перемещена или удалена.
            this.тип_продукцииTableAdapter.Fill(this.sbitDataSet.Тип_продукции);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "socZash1DataSet.Тип_обращения". При необходимости она может быть перемещена или удалена.
            this.тип_обращенияTableAdapter.Fill(this.socZash1DataSet.Тип_обращения);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
