﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Sotr1 : Form
    {
        public Sotr1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Sotr1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "sbitDataSet.Сотрудник". При необходимости она может быть перемещена или удалена.
            this.сотрудникTableAdapter.Fill(this.sbitDataSet.Сотрудник);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "socZash1DataSet.Специалист". При необходимости она может быть перемещена или удалена.
            this.специалистTableAdapter.Fill(this.socZash1DataSet.Специалист);

        }
    }
}
