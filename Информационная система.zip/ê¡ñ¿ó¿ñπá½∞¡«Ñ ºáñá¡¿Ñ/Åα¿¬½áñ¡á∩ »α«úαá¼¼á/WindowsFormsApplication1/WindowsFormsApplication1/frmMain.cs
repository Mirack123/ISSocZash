﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
            MaximizeBox = false;
            webBrowser1.Url = new Uri("https://82.202.172.211/phpmyadmin/index.php?token=8b4cd778c3067dfe874e73c1e966c8f7#PMAURL-3:sql.php?db=u107907_comment&table=Zapros&server=1&target=&token=8b4cd778c3067dfe874e73c1e966c8f7");
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "sbitDataSet.Входящие_обращения". При необходимости она может быть перемещена или удалена.
            this.входящие_обращенияTableAdapter1.Fill(this.sbitDataSet.Входящие_обращения);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "socZash1DataSet.Входящие_обращения". При необходимости она может быть перемещена или удалена.
            this.входящие_обращенияTableAdapter.Fill(this.socZash1DataSet.Входящие_обращения);
            (new frmLogon()).ShowDialog(this);//главной формой является эта форма, frmMain
        }

        private void button1_Click(object sender, EventArgs e)
        {
            входящие_обращенияTableAdapter1.Update(sbitDataSet);
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void руководствоToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Для внесения данных во входящие заявки нажмите на пустую строку базы данных и введите нужные значения, после чего нажмите на кнопку СОХРАНИТЬ, данные будут записаны!");
        }

        private void справкаToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Прикладная программа принадлежит бизнес единице СБЫТ под названием PEGAS. Прикладная программа была создана студентом Канского технологического колледжа - Ле Никитой Вуевичем!");
        }

        private void специалистToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sotr1 sf = new Sotr1();
            sf.Owner = this;
            sf.Show();
        }

        private void типОбращенияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Product1 sf = new Product1();
            sf.Owner = this;
            sf.Show();
        }

        private void окноToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Okno1 sf = new Okno1();
            sf.Owner = this;
            sf.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }
    }
}
